# City of God — cabelo 3D

Original: **FREE 21 Realtime Man Hairstyles Collection**

Autor: **Vincent Freelance** (Sketchfab)

Fonte: https://sketchfab.com/3d-models/free-21-realtime-man-hairstyles-collection-6a876007572c464da5184eb99af0c5f7

Licença identificada na página pública: **CC BY** (confirme no ZIP/licença original antes de distribuição pública).
Modificações: divididos 21 penteados em GLBs separados; cabeças e corpos de apresentação removidos; conversão de escala/origem para acessório no esqueleto do City of God; material de cor editável.

Crédito ao autor deve permanecer no site, documentação ou créditos internos do jogo.
